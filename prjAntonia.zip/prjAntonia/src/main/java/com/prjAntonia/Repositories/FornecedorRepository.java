package com.prjAntonia.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjAntonia.entities.Fornecedor;

public interface FornecedorRepository extends JpaRepository<Fornecedor, Long> {

}
