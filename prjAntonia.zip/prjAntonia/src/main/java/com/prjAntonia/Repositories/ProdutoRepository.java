package com.prjAntonia.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjAntonia.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long> {


}
