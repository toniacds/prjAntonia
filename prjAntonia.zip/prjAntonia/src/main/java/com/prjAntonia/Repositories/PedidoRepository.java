package com.prjAntonia.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjAntonia.entities.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
}
