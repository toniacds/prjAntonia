package com.prjAntonia.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjAntonia.Repositories.ClienteRepository;
import com.prjAntonia.entities.Cliente;

@Service
public class ClienteService {
	
	@Autowired
	private ClienteRepository clienteRepository;
	
	public List<Cliente>getAllCliente(){
		return clienteRepository.findAll();
	}
	
	public Cliente getClienteById(long clientcodigo) {
		return clienteRepository.findById(clientcodigo).orElse(null);
	}
	
	public Cliente saveCliente(Cliente cliente) {
		return clienteRepository.save(cliente);
	}

}
