package com.prjAntonia.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjAntonia.entities.Fornecedor;

@Service
public class FornecedorService {
	
	@Autowired
	private FornecedorService fornecedorRepository;
	
	public List<Fornecedor>getAllFornecedor(){
		return fornecedorRepository.findAll();
	}
	
	public Fornecedor getFornecedorById(long fornecodigo) {
		return fornecedorRepository.findById(fornecodigo).orElse(null);
	}
	
	public Fornecedor saveFornecedor(Fornecedor fornecedor) {
		return fornecedorRepository.save(fornecedor);
	}

}
