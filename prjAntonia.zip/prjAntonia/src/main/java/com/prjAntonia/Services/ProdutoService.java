package com.prjAntonia.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.auth.entities.Endereco;
import com.prjAntonia.Repositories.ProdutoRepository;
import com.prjAntonia.entities.Produto;

@Service
public class ProdutoService {
	
	@Autowired
	private ProdutoRepository produtoRepository;
	
	public List<Produto>getAllProduto(){
		return produtoRepository.findAll();
	}
	
	public Produto getProdutoById(long produtcodigo) {
		return produtoRepository.findById(produtcodigo).orElse(null);
	}
	
	public Produto saveProduto(Produto produto) {
		return produtoRepository.save(produto);
	}

}
