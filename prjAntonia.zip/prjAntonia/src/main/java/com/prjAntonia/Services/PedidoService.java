package com.prjAntonia.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjAntonia.Repositories.PedidoRepository;
import com.prjAntonia.entities.Pedido;

@Service
public class PedidoService {

	@Autowired
	private PedidoRepository pedidoRepository;
	
	public List<Pedido>getAllPedido(){
		return pedidoRepository.findAll();
	}
	
	public Pedido getPedidoById(long pedidcodigo) {
		return pedidoRepository.findById(pedidcodigo).orElse(null);
	}
	
	public Pedido savePedido(Pedido pedido) {
		return pedidoRepository.save(pedido);
	}

}
