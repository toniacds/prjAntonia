package com.prjAntonia.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjAntonia.Repositories.ItemPedidoRepository;
import com.prjAntonia.entities.ItemPedido;

@Service
public class ItemPedidoService {
	
	@Autowired
	private ItemPedidoRepository itemPedidoRepository;
	
	public List<ItemPedido>getAllItemPedido(){
		return itemPedidoRepository.findAll();
	}
	
	public ItemPedido getItemPedidoById(long itemcodigo) {
		return itemPedidoRepository.findById(itemcodigo).orElse(null);
	}
	
	public ItemPedido saveItemPedido(ItemPedido itemPedido) {
		return itemPedidoRepository.save(itemPedido);
	}


}
